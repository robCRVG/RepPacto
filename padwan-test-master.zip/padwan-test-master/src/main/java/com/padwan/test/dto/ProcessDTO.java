package com.padwan.test.dto;

public class ProcessDTO {

    private String planetAbreviado;
    private Integer rankingMultiplicado;
    private String classeAbreviado;

    public String getPlanetAbreviado() {
        return planetAbreviado;
    }

    public void setPlanetAbreviado(String planetAbreviado) {
        this.planetAbreviado = planetAbreviado;
    }

    public Integer getRankingMultiplicado() {
        return rankingMultiplicado;
    }

    public void setRankingMultiplicado(Integer rankingMultiplicado) {
        this.rankingMultiplicado = rankingMultiplicado;
    }

    public String getClasseAbreviado() {
        return classeAbreviado;
    }

    public void setClasseAbreviado(String classeAbreviado) {
        this.classeAbreviado = classeAbreviado;
    }
}
