package com.padwan.test;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PadwanTestApplicationTests {

	@Test
	void contextLoads() {
	}

}
